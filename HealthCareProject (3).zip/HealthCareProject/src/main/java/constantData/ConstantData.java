package constantData;

public class ConstantData {
	public final static String PropertyFilePath="src/main/java/Global.properties";
	public final static String ScreenshotPathPass="D:\\ScreenShots26thJuly\\"+Math.random()+"Testnew.jpeg";
	public final static String ScreenshotPathFail="D:\\ScreenShots26thJuly\\"+Math.random()+"Testnew.jpeg";
}
