package ConstantData;

public class constantData {
	
	public final static String PropertyFilePath= "src/main/java/Global.properties";
	public static final String ScreenShotPath="D:\\ScreenShots26thJuly\\"+Math.random()+"Testnew.jpeg";

}
