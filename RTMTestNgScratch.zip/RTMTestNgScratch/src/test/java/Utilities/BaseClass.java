package Utilities;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import ConstantData.constantData;

public class BaseClass {
	
	
	
	
	public static WebDriver driver;
	
	
	
	@BeforeSuite
	public void openBrowser() throws IOException
	{
		String browserName=FetchDataFromProperty.readDataFromProperty().getProperty("browser");
		if(browserName.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("URL"));
			driver.manage().window().maximize();
		}
		
		if(browserName.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("URL"));
			driver.manage().window().maximize();
		}
		
		if(browserName.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("URL"));
			driver.manage().window().maximize();
		}
		
		
		
		
		
		
	}
	
	public static void addImplicitWait()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	
	
		public static void takeScreenShot() throws IOException
		{
			if (driver != null) {

				TakesScreenshot srcshot=(TakesScreenshot)driver;
				File srcfile=srcshot.getScreenshotAs(OutputType.FILE);
				File DestFile=new File(constantData.ScreenShotPath);
				FileUtils.copyFile(srcfile, DestFile);
			    // ...save file
			} else {
			    System.out.println("Driver is null! Cannot take screenshot.");
			}
			
		}
		
		@AfterMethod
		public static void closeBrowser() throws InterruptedException
		{
			Thread.sleep(4000);
			driver.quit();
		}
		
		
		
		
	
	
	
	
	

}
