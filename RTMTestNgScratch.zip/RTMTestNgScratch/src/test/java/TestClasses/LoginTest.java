package TestClasses;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import PageClasses.LoginPage;
import Utilities.BaseClass;

public class LoginTest extends BaseClass {
	
	LoginPage obj=new LoginPage();
	
	
	@Test(priority=0,groups={"@sanity"})
	public  void executeLoginTest() throws InterruptedException
	{
		addImplicitWait();
		driver.findElement(By.xpath(obj.getUserName())).sendKeys("Admin");		
		driver.findElement(By.xpath(obj.getContinueButton())).click();		
		driver.findElement(By.xpath(obj.getPassword())).sendKeys("Admin123");		
		driver.findElement(By.xpath(obj.clickOnSubmit())).click();
	}
	
	
	
	
	
	
	
	
	
	
	

}
