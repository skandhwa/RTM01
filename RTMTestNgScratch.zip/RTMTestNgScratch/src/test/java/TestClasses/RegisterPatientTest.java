package TestClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import PageClasses.RegisterPage;
import Utilities.BaseClass;
import Utilities.ListenerImplementation;


@Listeners(ListenerImplementation.class)

public class RegisterPatientTest extends BaseClass {
	
	LoginTest obj1=new LoginTest();
	RegisterPage rpObj= new RegisterPage();
	
	
	@DataProvider(name="MyDp1")
	public Object [][] method()
	{
		return new Object [][] {{"Harry","dsouza","32","Mumbai"},
			
			{"Henry","Williamson","45","Kolkata"}};
		
	}
	
	@Test(dataProvider="MyDp1",groups={"@sanity"})
	public void addPatient(String fn,String ln, String ag,String add) throws InterruptedException
	{
		addImplicitWait();
		obj1.executeLoginTest();
		driver.findElement(By.xpath(rpObj.addPatientButton())).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.patientIdentityButton())).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.firstName())).sendKeys(fn);
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.lastName())).sendKeys(ln);
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.gender())).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.dobStataus())).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.age())).sendKeys(ag);
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.address())).sendKeys(add);
		Thread.sleep(3000);
		driver.findElement(By.xpath(rpObj.btnregPat())).click();
		Thread.sleep(3000);
		WebElement patId=driver.findElement(By.xpath(rpObj.validatePatID()));
		
		if(patId.isDisplayed()==true)
		{
			System.out.println("Test Case Passed");
		}
		else
		{
			throw new NullPointerException("Patient Registration Failed");
		}
		
		
		
		//driver.findElement(By.xpath(rpObj.closePg())).click();
		
		
		
		
		
	}
	
	
	
	

}
