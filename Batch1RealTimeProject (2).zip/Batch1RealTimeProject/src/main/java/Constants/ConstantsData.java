package Constants;

public class ConstantsData {
	
	public final static String PropertyFilePath="src/main/java/Global.properties";
	public final static String ExcelPath="E:\\LatestEclipseWorkspace\\ABSK05_Scratch_Project\\src\\main\\java\\TestData\\TestData28Feb2024.xlsx";
	
	
	

}
